<?php
include "nav.html";
include "body.php";
include "foot.html";
?>