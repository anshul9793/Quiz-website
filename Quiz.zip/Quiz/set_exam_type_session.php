<?php
session_start();
include "connection.php";

$exam_category = isset($_GET["exam_category"]) ? $_GET["exam_category"] : null;

if ($exam_category !== null) {
    $_SESSION["exam_category"] = $exam_category;

    $res = mysqli_query($conn, "SELECT * FROM ecam_category where category='$exam_category'");
    while ($row = mysqli_fetch_array($res)) {
        $_SESSION["exam_time"] = $row["exam_time_in_minutes"];
    }

    $data = date("Y-m-d H:i:s");
    $_SESSION["end_time"] = date("Y-m-d H:i:s", strtotime($data . "+{$_SESSION['exam_time']} minutes"));
    $_SESSION["exam_start"] = "yes";
} else {
    echo "Exam category not specified.";
}
?>
