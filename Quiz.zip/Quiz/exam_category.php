<?php
include "admin_header.php";
include "connection.php";

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit1"])) {
    $formSubmitted = true;

    $examname = $conn->real_escape_string($_POST["examname"]);
    $examtime = $conn->real_escape_string($_POST["examtime"]);

    // Validate if fields are not empty
    if (empty($examname) || empty($examtime)) {
        $errorMsg = "Please fill in all fields.";
    } else {
        // Check if the exam category already exists.
        $checkSql = $conn->prepare("SELECT * FROM exam_category WHERE category = ?");
        $checkSql->bind_param("s", $examname);
        $checkSql->execute();
        $result = $checkSql->get_result();

        if ($result->num_rows > 0) {
            // Already exists
            $errorMsg = "Error: Exam category already exists.";
        } else {
            // Insert new records
            $insertSql = $conn->prepare("INSERT INTO exam_category (category, exam_time_in_minutes) VALUES (?, ?)");
            $insertSql->bind_param("ss", $examname, $examtime);

            if ($insertSql->execute()) {
                $successMsg = "Exam category added successfully";
            } else {
                $errorMsg = "Error: " . $insertSql->error;
            }
        }
        $checkSql->close();
    }
}
?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Add Exam</h1>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <form action="" name="form1" method="post">
                    <div class="card-body">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-header"><strong>Add Exam</strong></div>
                                <div class="card-body card-block">
                                    <div class="form-group"><label for="company" class=" form-control-label">New Exam
                                            Category</label><input type="text" name="examname"
                                            placeholder="Add exam category" class="form-control"></div>
                                    <div class="form-group"><label for="exam" class=" form-control-label">Exam Time In
                                            Minutes</label><input type="text" name="examtime" placeholder="Exam time in minutes"
                                            class="form-control"></div>


                                    <div class="form-group">
                                        <input type="submit" name="submit1" value="Add Exam" class="btn btn-success">
                                               
                                       <button class="btn btn-danger"><a href="exam_del.php">Edit Exam</a></button>
                                    
                                    </div>
                            

                                </div>
                            </div>
                        </div>
                        
                    </div>
                    </form>
                </div> <!-- .card -->
            </div>
        </div>
    </div>


    <?php
// Display success or error messages here
if (!empty($successMsg)) {
    echo "<p class='success-message'>$successMsg</p>";
}
if (!empty($errorMsg)) {
    echo "<p class='error-message'>$errorMsg</p>";
}

include "admin_footer.php";
?>