<?php
include "admin_header.php";
include "connection.php";

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

// Check if the form is submitted for updating details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $id = $conn->real_escape_string($_POST['id']);
    $category = $conn->real_escape_string($_POST['category']);
    $exam_time = $conn->real_escape_string($_POST['exam_time']);

   // Update the exam details in the database
$update_sql = "UPDATE exam_category SET category=?, exam_time_in_minutes=? WHERE id=?";
$update_stmt = $conn->prepare($update_sql);
$update_stmt->bind_param("sii", $category, $exam_time, $id);
$update_stmt->execute();

// Check if the update was successful
if ($update_stmt->affected_rows > 0) {
    $successMsg = "Exam details updated successfully!";
} elseif ($update_stmt->affected_rows === 0) {
    $errorMsg = "No changes made. The provided details are the same as the existing ones.";
} else {
    $errorMsg = "Invalid exam ID.";
}

$update_stmt->close();

}

// Initialize variables
$id = isset($_GET['id']) ? $conn->real_escape_string($_GET['id']) : '';
$category = '';
$exam_time = '';

// Check for the edit request
if ($id) {
    // Fetch data of the selected exam
    $select_sql = "SELECT * FROM exam_category WHERE id=?";
    $select_stmt = $conn->prepare($select_sql);
    $select_stmt->bind_param("i", $id);
    $select_stmt->execute();
    $result = $select_stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $category = htmlspecialchars($row['category']);
        $exam_time = htmlspecialchars($row['exam_time_in_minutes']);
    } else {
        $errorMsg = "Invalid exam ID.";
    }

    $select_stmt->close();
}

?>

<div class="container mt-5 mb-5">
    <h2 class="text-center">Edit Exam Details</h2>
    <?php
    // Display success or error messages here
    if (!empty($successMsg)) {
        echo "<p class='success-message'>$successMsg</p>";
    }
    if (!empty($errorMsg)) {
        echo "<p class='error-message'>$errorMsg</p>";
    }
    ?>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <div class="form-group">
            <label for="category">Exam Category:</label>
            <input type="text" class="form-control" name="category" value="<?php echo $category; ?>" required>
        </div>
        <div class="form-group">
            <label for="exam_time">Exam Time (Minutes):</label>
            <input type="number" class="form-control" name="exam_time" value="<?php echo $exam_time; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Exam</button>
        <button class="btn btn-secondary"><a href="exam_del.php">Go back</a></button>
    </form>
    </form>
</div>

<?php
include "admin_footer.php";
?>
