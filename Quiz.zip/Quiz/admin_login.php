<?php
session_start();
include "connection.php";

$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $formSubmitted = true;

    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);

    // Fetch the admin's data from the database
    $sql = "SELECT username, password FROM admin_login WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Authentication successful
        $_SESSION['admin_username'] = $username;

        // Redirect to the admin dashboard or any other page for admin
        header("Location: dashboard.php");
        exit();
    } else {
        $errorMsg = "Incorrect username or password.";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
<?php
include "nav.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Young+Serif&display=swap" rel="stylesheet">
<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
/>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>



.login-box {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    width: 400px;
    margin: 80px auto;
}



form {
    display: flex;
    flex-direction: column;
}

label {
    margin: 10px 0;
    font-weight: bold;
}

input, select {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid black;
    border-radius: 4px;
}

button {
    background-color: blue;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}
.log{
    text-align:center;
    letter-spacing:1px;
}

    </style>
</head>
<body>
   
<div class="login-container">
        <div class="login-box">
            <?php if ($formSubmitted && $errorMsg != ""): ?>
                <p style="color: red;"><?php echo $errorMsg; ?></p>
            <?php endif; ?>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" method="post">
            <label for="userType" class="log"><i class="fas fa-user"></i> Admin Login :)</label>
                

                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>
<br/>
                <button type="submit">Login</button><br/>
              
            </form>
        </div>
    </div>


    

</div>

</body>
<?php
include "foot.html";
?>
</html>