<?php
session_start();

include "connection.php"; // Include your database connection file

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;
$imageSubmitted = false;

// Check if the form was submitted
if (isset($_POST["submitProfile"])) {

    $formSubmitted = true;

    // Sanitize and fetch form data
    $name = $conn->real_escape_string($_POST['name']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $address = $conn->real_escape_string($_POST['address']);
    $state = $conn->real_escape_string($_POST['state']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $password = $conn->real_escape_string($_POST['password']);

    // Image upload logic
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["File"]["name"]);
    $uploadOk = true;

    // Image file upload logic here
    // Add your file type validation or other checks if needed

    // Disable foreign key checks
    $conn->query("SET foreign_key_checks = 0");

    if (!$uploadOk) {
        $errorMsg = "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["File"]["tmp_name"], $target_file)) {
            $sqlImage = "INSERT INTO uimage (filename) VALUES ('$target_file')";
            if ($conn->query($sqlImage) === TRUE) {
                $last_image_id = $conn->insert_id;  // Fetch the last inserted image ID

                // Encrypt the password
                $hashedPwd = password_hash($password, PASSWORD_DEFAULT);

                // Set the role directly to "2" (Student)
                $role = '2';

                // SQL query to insert data into your table
                $sql = "INSERT INTO students (pid, name, username, email, password, gender, dob, address, state, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                // Prepare and bind
                $stmt = $conn->prepare($sql);

                // Check for a successful preparation
                if ($stmt !== false) {
                    $stmt->bind_param("issssssssss", $last_image_id, $name, $username, $email, $hashedPwd, $gender, $dob, $address, $state, $phone, $role);

                    // Execute the statement
                    if ($stmt->execute()) {
                        $successMsg = "<br>Student Added successfully";

                        // Store user data in the session
                        $_SESSION['username'] = $username;
                        $_SESSION['role'] = $role;
                        $_SESSION['name'] = $name;
                        $_SESSION['image_id'] = $last_image_id;

                        // Redirect to login.php
                        header("Location: login.php");
                        exit();
                    } else {
                        $errorMsg = "Error: " . $stmt->error;
                    }
                } else {
                    $errorMsg = "Error in preparing the SQL statement: " . $conn->error;
                }
            } else {
                $errorMsg = "Error: " . $sqlImage . "<br>" . $conn->error;
            }
        } else {
            $errorMsg = "Sorry, there was an error uploading your file.";
        }
    }
}

?>
<?php
include "nav.html";
?>
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="favicon.png">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Young+Serif&display=swap" rel="stylesheet">
<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
body {  
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 50%;
    height:auto;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.showw{
    width:200px;
    height: 200px;
    border: 2px solid black;
    align-content: end;
}
.profile-form {
    display: inline;
    /* flex-wrap: wrap; */
}

.form-column {
    flex: 0 0 45%; /* Adjust the width as needed */
    margin-right: 5%; /* Adjust the margin between columns */
}

.form-group {
    margin: 15px;
    
}

label {
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 8px;
    margin-top: 8px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}

select {
    height: 34px;
}

.bttn {
    background-color: #4caf50;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.bttn:hover {
    background-color: #45a049;
}



  </style>
</head>
<body>



<div class="container">
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data" class="profile-form">
            <div class="form-group">
                <div id="Show" class="showw"> </div>
                <label for="File">Select Profile Image:</label>
                <br/>
                <input type="File" name="File" id="File" onchange="ImagePreview(event)">
                <br/>
            </div>

           


            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" required onkeyup ="spaces()">
                <error id= "error"> </error>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required onkeyup = "pass()">
                <error id= "error1"> </error>
            </div>

            <div class="form-group">
                <label for="gender">Gender</label>
                <select name="gender" id="gender">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" name="address" id="address">
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <input type="text" name="state" id="state">
            </div>

            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="tel" name="phone" id="phone">
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" name="dob" id="dob">
            </div>

            <!-- <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role">
                    <option value="1">Admin</option>
                    <option value="2">Student</option>
                </select>
            </div> -->

            <input type="submit" name="submitProfile" value="Submit Profile" class="bttn">
        </form>
    </div>



</div>

</body>
<?php
include "foot.html";
?>
<script>
function ImagePreview(event){

    var image1 = URL.createObjectURL(event.target.files[0]);
    var imagediv = document.getElementById('Show');
    var newimage = document.createElement('img');
    imagediv.innerHTML = "";
      newimage.src = image1;
      newimage.width="200";
      newimage.height="200";
    imagediv.appendChild(newimage);
}


    </script>

<script>


document.getElementById('error').style.color ="red"; 
document.getElementById('error1').style.color ="red"; 

function spaces(){
    var a = document.getElementById('name').value;
    var b = /^[A-Za-z\s]+$/;
   if( a.length>0){
   
    if(!a.match(b)){
        document.getElementById('error').innerText = "! Oh Please Enter only Alphabets.";
   }
 

   else{
    document.getElementById('error').innerText = "";

   }
}


else if(a.length >20){
    document.getElementById('error').innerText = "Name is not more than 20 Alphabets.";
}


else{
    document.getElementById('error').innerText = "";
}


}


function pass(){
    var pass = document.getElementById('password').value;
    if( pass.length > 0){
        if(pass.length<4){
    document.getElementById('error1').innerText = "! Please enter atleast 8 chars";
    }

//   else if(pass.length>8){
//    document.getElementById('error1').innerText = "! Please enter less than 8 chars";

//   }
  
  else if(pass.search(/[0-9]/)==-1){
   document.getElementById('error1').innerText = "! Please enter atleast 1 numeric chars";

  }
  else if(pass.search(/[a-z]/)==-1){
   document.getElementById('error1').innerText = "! Please enter atleast 1 a-z chars";

  }
  else if(pass.search(/[A-Z]/)==-1){
   document.getElementById('error1').innerText = "! Please enter atleast 1 A-Z chars";

  }
  else if(pass.search(/[!@#$%^&*]/)==-1){
   document.getElementById('error1').innerText = "! Please enter atleast 1 special chars";

  }
  
  else{
   document.getElementById('error1').innerText = "";

  }


}
else{
   document.getElementById('error1').innerText = "";

  }
}
    </script>

</html>