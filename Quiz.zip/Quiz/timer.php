<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <style>
    body {
      margin: 0px;
      padding: 0;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: url("timer.jpg")center/cover no-repeat;;
      
    }

    #timer-container {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      background-color: red;
      color: #fff;
      font-size: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    h1{
        text-align:center;
        color:white;
        font-weight:bold;
    }
  </style>
</head>
<body>
<h1> Your Quiz will Start in &nbsp;&nbsp;&nbsp;</h1>
<div id="timer-container">3</div> 

<script>
  function Timer() {
    var countdown = 3; 
    var timerInterval = setInterval(function () {
      document.getElementById('timer-container').innerText = countdown;
      countdown--;

      if (countdown < 0) {
        clearInterval(timerInterval);
        window.location.href = 'quizquestion.php?n=1';
      }
    }, 1000);
  }

  // Start the countdown when the page loads
  window.onload = function () {
    Timer();
  };
</script>

</body>
</html>
