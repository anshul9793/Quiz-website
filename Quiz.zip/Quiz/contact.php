<?php
include "nav.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .div1{
    background-color: whitesmoke;
    border-radius: 10px;
  padding: 20px;
}
.div1 h1{
    color: #324a8e;
}
    </style>
<body>
<div class="container266">
  
  <div class="div1" data-aos="fade-right">
      <h1> Contact Us</h1>
     <br/> <hr/><br/>
      <!-- <img class="imgg" src="cdactext.jpg" > -->
      <a> <iframe class="mapp" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13717.286700812103!2d76.7990263!3d30.7374646!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390fede54313efc5%3A0xcde0b205f25a939!2sChief%20Electoral%20Office%2C%20Punjab!5e0!3m2!1sen!2sin!4v1702487732713!5m2!1sen!2sin" width="800" height="550" style="border: 1px solid black; margin-right:100px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></a>
          <h2>The Chief Electoral <br> Officer, Punjab<h2>
<h4>SCO 29-32, Sector 17-E, Chandigarh-160017
Tollfree Phone Number: 1950
      </h4>
          </div>
</div>

</body>
<?php
include "foot.html";
?>
</html>