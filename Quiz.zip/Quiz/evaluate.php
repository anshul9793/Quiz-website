<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Evaluation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: whitesmoke;
            font-family: 'Young Serif', serif;
            text-align: center;
            margin: 50px;
        }

        h2 {
            color: #3498db;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 10px;
        }

        .result-container {
            width: 50%;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .btn {
            padding: 10px;
            width: 150px;
            font-size: 16px;
            margin-top: 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<?php
session_start();
include "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $examCategory = $_POST['examCategory'];
    $questionNumbers = $_POST['question_no'];
    $selectedAnswers = isset($_POST['answer']) ? $_POST['answer'] : [];

    // Fetch correct options from the database
    $sql = "SELECT question_no, answer FROM questions WHERE category = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $examCategory);
    $stmt->execute();
    $result = $stmt->get_result();

    $correctOptions = [];
    while ($row = $result->fetch_assoc()) {
        $correctOptions[$row['question_no']] = $row['answer'];
    }

    // Evaluate marks
    $marksPerQuestion = 10;
    $totalMarks = 0;

    foreach ($questionNumbers as $questionNo) {
        $correctOptionId = $correctOptions[$questionNo];
        $userAnswer = isset($selectedAnswers[$questionNo]) ? $selectedAnswers[$questionNo] : null;

        // Compare the selected option with the correct option's id
        if ($userAnswer == $correctOptionId) {
            $totalMarks += $marksPerQuestion;
        }
    }

    // Display marks
    echo "<div class='result-container'>";
    echo "<h2>Your Quiz Results</h2>";
    echo "<p>Exam Category: $examCategory</p>";
    echo "<p>Marks Obtained: $totalMarks</p>";
    echo "<a href='quizquestion.php' class='btn'>Take Another Quiz</a>";
    echo "</div>";
} else {
    // Redirect to the quiz page if accessed directly without form submission
    header("Location: quizquestion.php");
    exit();
}
?>


</body>
</html>
