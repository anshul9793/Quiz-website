<?php
session_start();
include "connection.php";

if (isset($_SESSION['username'])) {
  $username = $_SESSION['username'];
  $role = $_SESSION['role'];

  $sql = "SELECT 
      students.*, 
      uimage.filename AS filename
    
  FROM students 
  LEFT JOIN uimage ON students.Pid = uimage.id  
 
  WHERE students.Username = ?";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
} else {
      echo "<div class='container mt-5'><p>User profile not found.</p></div>";
  }
} 
else {
  header  ("Location : run.php");
  echo "<div class='container mt-5'><p>Please log in to view this page.</p></div>";
}


$query = "SELECT * FROM questions";
$totalquestions = mysqli_num_rows(mysqli_query($conn,$query));
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chief Electoral Officer, Punjab</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!-- Other CSS files -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Young+Serif&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="fav.png">
  <style>
     * {
        margin: 0;
        padding: 0;
        font-family: 'Young Serif', serif;
    }

    body {
        background-color: whitesmoke;
    }

    .header {
        min-height: 100vh;
        width: 100%;
        background-position: center;
        background-size: cover;
        position: relative;
    }

    .nav {
        display: flex;
        padding: 5px 5px;
        justify-content: space-between;
        align-items: center;
                background-color: white;

    }

    #Nav{
        background-color: #073e53;
    }

    .navbar-brand img {
        width: 50px; /* Adjust as needed */
        height: auto;
    }

    .textbox {
        flex: 5;
        text-align: center;


    }

    .textbox h1 {
   
        color: Black;
        font-size: 18px; /* Adjust as needed */
        font-weight: bold;
        margin-top: 5px; /* Adjust as needed */
    }
    .textbox h1:hover {
    color: grey;
    animation: rubberBand;
    animation-duration: 3s;
    transition: all linear 5s;
    animation-iteration-count: infinite;
}


.navbar-toggler{
  padding: 0.25rem 0.75rem;
    font-size: 1.25rem;
    line-height: 1;
    background-color: white;
    border: 1px solid black;
    border-radius: 0.25rem;
}
    .nav-links {
        text-align: right;
        color:white;
    }

    .nav-links ul {
        list-style: none;
        display: flex;
        justify-content: flex-end;
        align-items: center;
                color:white;

    }

    .nav-links ul li {
        margin: 0 10px; /* Adjust as needed */
        color:white;
    }
    
    .nav-links ul li a {
        text-decoration: none;
        color: white;
        font-size: 16px;
        font-weight: bold;
        border-radius: 3px;
    }
     .collapse a{
        color:white;
     }
    .collapse a::after {
        width: 0px;
        content: "";
        height: 2px;
        display: block;
        margin: auto;
        background-color: white;
        transition: all linear 1s;
    }

    .collapse a:hover::after {
        width: 100%;
        background-color: red;
    }
    .img img{
        height:100px;
        width:100px;
        padding:10px;

    }
    #google_translate_element{
       display: flex;
       justify-content: flex-end;
    }
   
    #quiz-container {
      width: 90%;
      max-width: 500px;
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin: 30px auto;
    }
   
    h2 {
      text-align: center;
      color:#ffc107;
    }

    label {
      display: block;
      margin-top: 10px;
    }

    select, button {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      box-sizing: border-box;
      border-radius:10px;
    }

    .checkbox-label {
      display: flex;
      align-items: center;
    }

    .checkbox-label input {
      margin-left: 10px;
    }

    #play-btn {
      display: block;
      margin-top: 20px;
      padding: 10px;
      background-color: #3498db;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-decoration:none;
    }
    .play-btn-container {
      display: block;
      margin-top: 20px;
      text-align: center;
      
    }

    .play-btn {
      display: inline-block;
      padding: 10px;
      width:95%;
      max-width:500px;
      background-color: #3498db;
      color: black;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-decoration: none; /* Disable underline */
    }
    .play-btn:hover{
        text-decoration:none;
        color:white;
    }
  .login{
    display:flex;
    justify-content:flex-end;
  }
  

.profile-dropdown-btn {
  width: auto;
  border-radius: 5px;
  cursor: pointer;
  transition: box-shadow 0.2s ease-in, background-color 0.2s ease-in,
    border 0.3s;
}

.profile-dropdown-list {
  position: absolute;
  top: 60px;
  width: 250px;
  right: 0;
  background-color: grey;
  border-radius: 10px;
  max-height: 0;
  overflow: hidden;
  box-shadow: var(--shadow);
  z-index:1;
  
}

.profile-dropdown-list.active {
  max-height: 500px;
}

.profile-dropdown-list-item {
  padding: 0.5rem 0rem 0.5rem 1rem;
  transition: background-color 0.2s ease-in, padding-left 0.2s;
}

.profile-dropdown-list-item a {
  display: flex;
  align-items: center;
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
  color: var(--black);
}

.profile-dropdown-list-item a i {
  margin-right: 0.8rem;
  font-size: 1.1rem;
  width: 2.3rem;
  height: 2.3rem;
  background-color: var(--secondary);
  color: var(--white);
  line-height: 2.3rem;
  text-align: center;
  margin-right: 1rem;
  border-radius: 50%;
  transition: margin-right 0.3s;
}

.profile-dropdown-list-item:hover {
  padding-left: 1.5rem;
  background-color: var(--secondary-light);
}

.login li{
  list-style:none;
}
#google_translate_element{
       display: flex;
       justify-content: flex-end;
    }

    @media (max-width: 600px) {
      #quiz-container {
        width: 100%;
        border-radius: 0;
      }
    
    }
  </style>
</head>
<body>
    <div id="google_translate_element"> </div>

    <!-- Bootstrap Navbar -->
    <nav class="navbar nav navbar-expand-lg img  ">
        <a class="navbar-brand" href="run.php">
            <img src="new.png" class="logo" alt="Logo">
        </a>
        <div class="textbox">
            <h1 class="navbar-text">
                ਮੁੱਖ ਚੋਣ ਅਫ਼ਸਰ, ਪੰਜਾਬ <br/>Chief Electoral Officer, Punjab
            </h1>
        </div>
 <a class="navbar-brand" href="run.php">
            <img src="new1.png" class="logo" alt="Logo">
        </a>
    </nav>

<div class="container-fluid p-0 " id="Nav">
    <nav class="navbar navbar-expand-lg   ">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNav">
            <ul class="navbar-nav ">

                <div>
                <li class="nav-item">
                    <a class="navbar-brand" href="run.php">
                        <i class="fas fa-home"></i>
                    </a>
                </li>
            </div>
            <div>
                <li class="nav-item">
                    <a class="nav-link" href="run.php">Home</a>
                </li>
            </div>
            <div>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
            </div>
            <div>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
            </div>
            <div>
                 <li class="nav-item">
                    <a class="nav-link" href="register.php">Register </a>
                </li>
            </div>
           
 

            </ul>
        </div>
        <div class="login">
            <li class ="profile-dropdown-btn " >  <a href="">  <img  onclick="toggle()" src="<?php echo $row["filename"]; ?>" alt="Profile Picture" onclick="toggleDropdown()" class="profie-picture" style="width: 30px; height: 30px; border-radius: 50%;">
            Login as <?php 
            echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>
            
            <i class="fa-solid fa-angle-down "></i>
        
        </a> </li>
  </div>
  <ul class="profile-dropdown-list">

<li class="profile-dropdown-list-item">
  <a href="">
    Edit Profile
    <i class="fa-regular fa-user"></i>

  </a>
</li>


<li class="profile-dropdown-list-item">
  <a href="#">
    Help & Support
    <i class="fa-regular fa-circle-question"></i>

  </a>
</li>

<li class="profile-dropdown-list-item">
  <a href="logout.php">
    Log out
    <i class="fa-solid fa-arrow-right-from-bracket"></i>

  </a>
</li>


</ul>
        
    </nav>


</div>
<div id="quiz-container">
  <h2>Welcome to Quiz Section</h2>

  <label for="language">Select Language:</label>
  <select id="language" name="language">
 

    <option value="lang">--Choose-Your-Language--</option>
    <option value="english">English</option>
    <option value="hindi" >Hindi</option>
    <option value="punjabi">Punjabi</option>
  </select>
  <script>
  document.getElementById('language').addEventListener('change', function () {
    var selectedLanguage = this.value;
    if (selectedLanguage === 'hindi') {
      document.documentElement.lang = 'hi';
    } else {
      document.documentElement.lang = 'en';
    }
  });
</script>
  <label for="subject">Select Subject:</label>
  <select id="subject" name="subject">
    <option value="subject">--Choose-Your-Subject--</option>
    <option value="gk">General Knowledge</option>
    <option value="science">Science</option>
    <option value="computer">Computer</option>
  </select>

 

 <br/>
 <br/>
 

  <label>
    <input type="checkbox" id="terms" name="terms"> Terms and Conditions:-
  </label>
 
  <p>1.Total Questions: <?php echo $totalquestions; ?></p>
  <p>2.Total Marks: 100</p>
  <p>3.Questions are of MCQ type.</p>
  <p>4. You have to choose only one option.</p>
  <p>5. No negative marking.</p>
  
 <br/>
 
  <label for="ready">
    <input type="checkbox" id="ready" name="ready"> 
 Are you Ready.</label>

 <!-- <a class="play" href="timer.php"><button id="play-btn"> Play</button></a> -->

 
 <div class="play-btn-container">
    <a class="play-btn" href="timer.php">Play</a>
  </div>
</div>

</body>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script type="text/javascript">
function googleTranslateElementInit() {
  var translator = new google.translate.TranslateElement({
    pageLanguage: 'en', // Set default language to English
    includedLanguages: 'en,hi,pa', // Include English, Hindi, and Punjabi
    layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
    autoDisplay: false // Disable the "Translated by Google" header and the Google logo
  }, 'google_translate_element');

  // Add a language change event listener
  google.translate.elements.setOnLanguageChange(function (event) {
    // Get the selected language
    var selectedLanguage = event.target.getSelectedLanguage();

    // Change the language of the translator without displaying any message
    translator.changeLanguage(selectedLanguage);
  });
}
</script>
<script>
//first js

let profileDropdownList = document.querySelector(".profile-dropdown-list");
let btn = document.querySelector(".profile-dropdown-btn");

let classList = profileDropdownList.classList;

btn.addEventListener("mouseenter", function () {
  classList.add("active");
});

window.addEventListener("click", function () {
  classList.remove("active");
});
</script>
<?php
include "foot.html";
?>
</html>
