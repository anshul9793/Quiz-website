<?php 

include "connection.php";
session_start();

if (!isset($_SESSION['score'])){
    $_SESSION['score'] = 0;

}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $query = "SELECT * FROM questions";
    $totalquestions = mysqli_num_rows(mysqli_query($conn,$query));

    $number = $_POST['number'];

    
    $selectedchoice = $_POST['choice'];
    $next = $number+1;

$query = "SELECT *FROM options WHERE qnum = $number AND correct = 1";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);


$correctchoice = $row['id'];

if ( $selectedchoice == $correctchoice){
  
   $_SESSION['score']+=5;

}
if($number == $totalquestions){
    header("Location: final.php");

}
else{
    header("Location: quizquestion.php?n=". $next);
}


}



?>