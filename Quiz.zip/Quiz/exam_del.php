<?php
include "admin_header.php";
include "connection.php";

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

// Check for delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $conn->real_escape_string($_GET['delete_id']);

    $delete_sql = "DELETE FROM exam_category WHERE id=?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    $delete_stmt->execute();
    $delete_stmt->close();

    // Check if any row was affected (exam deleted)
    if ($conn->affected_rows > 0) {
        $successMsg = "Exam deleted successfully!";
    } else {
        $errorMsg = "No exam deleted.";
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Fetch data from the exam_category table
$sql = "SELECT * FROM exam_category";
$result = $conn->query($sql);

?>

<div class="container mt-5 mb-5">
    <h2 class="text-center">List of Exams</h2>
    <?php
    // Display success or error messages here
    if (!empty($successMsg)) {
        echo "<p class='success-message'>$successMsg</p>";
    }
    if (!empty($errorMsg)) {
        echo "<p class='error-message'>$errorMsg</p>";
    }

    if ($result->num_rows > 0) {
        echo "<table class='table'>
            <thead>
                <tr>
                    <th>Sr. no.</th>
                    <th>Exam Category</th>
                    <th>Exam Time (Minutes)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>";

        $serialNumber = 1;
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $serialNumber . "</td>
                    <td>" . htmlspecialchars($row["category"]) . "</td>
                    <td>" . htmlspecialchars($row["exam_time_in_minutes"]) . "</td>
                    <td class='btn-container'>
                        <a href='exam_edit.php?id=" . $row["id"] . "' class='btn btn-primary btn-sm'>Edit</a>
                        <a href='" . $_SERVER['PHP_SELF'] . "?delete_id=" . $row["id"] . "' class='btn btn-danger btn-sm'>Delete</a>
                    </td>
                    
                </tr>";
            $serialNumber++;
        }

        echo "</tbody>
        
            </table>";
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
    ?>
  <div class="text-center mt-3">
        <button class="btn btn-secondary"><a href="exam_category.php">Go Back</a></button>
    </div>
</div>

<?php
include "admin_footer.php";
?>
