<?php
include "admin_header.php";
include "connection.php";

$id = isset($_GET["id"]) ? $_GET["id"] : null;

if (!$id) {
    echo "Question ID not provided.";
    exit;
}

$questionSql = "SELECT * FROM questions WHERE id = $id";
$questionResult = mysqli_query($conn, $questionSql);

if (!$questionResult || mysqli_num_rows($questionResult) == 0) {
    echo "Question not found.";
    exit;
}

$question = mysqli_fetch_array($questionResult);

// Handle form submission for updating the question
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $newQuestion = $conn->real_escape_string($_POST["question"]);
    $newOpt1 = $conn->real_escape_string($_POST["opt1"]);
    $newOpt2 = $conn->real_escape_string($_POST["opt2"]);
    $newOpt3 = $conn->real_escape_string($_POST["opt3"]);
    $newOpt4 = $conn->real_escape_string($_POST["opt4"]);
    $newAnswer = $conn->real_escape_string($_POST["answer"]);

    $updateSql = $conn->prepare("UPDATE questions SET question = ?, op1 = ?, op2 = ?, op3 = ?, op4 = ?, answer = ? WHERE id = ?");
    $updateSql->bind_param("ssssssi", $newQuestion, $newOpt1, $newOpt2, $newOpt3, $newOpt4, $newAnswer, $id);

    if ($updateSql->execute()) {
        $successMsg = "Question updated successfully!";
    } else {
        $errorMsg = "Error updating question: " . $updateSql->error;
    }

    $updateSql->close();
}
?>

<div class="breadcrumbs">
    <div class="col-sm-8">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Edit Question</h1>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <strong>Edit Question</strong>
                    </div>
                    <div class="card-body card-block">
                        <form action="" method="post">
                            <div class="form-group">
                                <label for="question" class="form-control-label">Question</label>
                                <input type="text" name="question" value="<?php echo htmlspecialchars($question['question']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="opt1" class="form-control-label">Option 1</label>
                                <input type="text" name="opt1" value="<?php echo htmlspecialchars($question['op1']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="opt2" class="form-control-label">Option 2</label>
                                <input type="text" name="opt2" value="<?php echo htmlspecialchars($question['op2']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="opt3" class="form-control-label">Option 3</label>
                                <input type="text" name="opt3" value="<?php echo htmlspecialchars($question['op3']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="opt4" class="form-control-label">Option 4</label>
                                <input type="text" name="opt4" value="<?php echo htmlspecialchars($question['op4']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="answer" class="form-control-label">Answer</label>
                                <input type="text" name="answer" value="<?php echo htmlspecialchars($question['answer']); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="submit" value="Update Question" class="btn btn-success">
                                <button class="btn btn-secondary">
                                    <a href="view_questions.php">Go back</a>
                                </button>
                            </div>
                        </form>
                        <?php
                        if (isset($successMsg)) {
                            echo '<div class="alert alert-success" role="alert">' . $successMsg . '</div>';
                        }
                        if (isset($errorMsg)) {
                            echo '<div class="alert alert-danger" role="alert">' . $errorMsg . '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "admin_footer.php";
?>
