<?php
include"admin_header.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
   
    <style>
       

        .dashboard-container {
            width: 50%;
            margin: auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
            margin-bottom: 20px;
        }

        .info-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .info-box {
            flex-basis: 48%;
            background-color: #007bff;
            color: #ffffff;
            padding: 20px;
            border-radius: 8px;
        }

        .info-box p {
            font-size: 18px;
            margin: 0;
            color:#fff;
        }

        .btn {
            padding: 10px;
            width: 150px;
            font-size: 16px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php
include "connection.php";

// Count total number of students
$sqlStudents = "SELECT COUNT(*) AS totalStudents FROM students";
$resultStudents = $conn->query($sqlStudents);
$rowStudents = $resultStudents->fetch_assoc();
$totalStudents = $rowStudents['totalStudents'];

// Count total number of quizzes
$sqlQuizzes = "SELECT COUNT(*) AS totalQuizzes FROM exam_category";
$resultQuizzes = $conn->query($sqlQuizzes);
$rowQuizzes = $resultQuizzes->fetch_assoc();
$totalQuizzes = $rowQuizzes['totalQuizzes'];
?>

<div class="dashboard-container">
    <h2>Dashboard</h2>

    <div class="info-container">
        <div class="info-box">
            <p>Total Number of Students</p>
            <p><?php echo $totalStudents; ?></p>
        </div>

        <div class="info-box">
            <p>Total Number of Quizzes</p>
            <p><?php echo $totalQuizzes; ?></p>
        </div>
    </div>

    <!-- Example link to go back to the quiz page -->
    <a href="quizquestion.php" class="btn">Go to Quiz Page</a>
</div>

</body>
</html>

<?php
include"admin_footer.php";
?>