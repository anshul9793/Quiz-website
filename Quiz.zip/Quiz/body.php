
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
        .maindiv{
    width: 100%;
    height: 400px;
    position: relative;
    top: 200px;
    left:50%;
    transform: translate(-50%,-50%);
    background-image: url("cdacimage.jpg");
    background-size: 100% 100%;
    box-shadow: 2px 2px 8px 4px white;
    border-radius: 5px;
    animation: slide 12s infinite linear;
    margin-bottom: 50px;
    
} 

@keyframes slide {
    0%{
background-image: url("ban.jpg");
    }
    25%{
        background-image: url("ban1.jpg");

    }
    50%{
        background-image: url("ban2.jpg");

    }
    75%{
        background-image: url("ban3.jpg");

    }
  
}

.contain{
    margin-bottom: 50px;
}

.contain img{
   height:200px;
   border-radius:30px;
   
}
.div1{
    background-color: whitesmoke;
    border-radius: 10px;
  padding: 20px;
}
.div1 h1{
    color: #324a8e;
}


.imgg{
    width: 250px;
    height: 250px;
    border-radius: 50%;
    border: 3px solid white;
    float: left;
    shape-outside: circle();
    margin: 10px;
    /* box-shadow: 0px 0px 21px blue; */
}
.div2{
    width: 200px;
    height: 150px;
    border: 2px solid black;
    background-color: whitesmoke;
    margin-top: 180px;
margin-right: 20px;
float: left;

position: relative;
}
 .div3{
    width: 200px;
    height: 150px;
    border: 2px solid black;
    background-color: whitesmoke;
    clear: both;
    position: absolute;
    top: 370px;
    left: 800px;


} 
.div4{
    width: 200px;
    height: 150px;
    border: 2px solid black;
    background-color: whitesmoke;
    clear: both;
    position: absolute;
    top: 370px;
    left: 1022px;
  
} 

.div5{
    width: 200px;
    height: 150px;
    border: 2px solid black;
    background-color: whitesmoke;
    clear: both;
    position: absolute;
    top: 560px;
    left: 800px;
  

} 
.div2 h2 {
    position: absolute;
    left: 80px;
    top: 26px;
}

.div3 h2 {
    position: absolute;
    left: 80px;
    top: 26px;
}
.div4 h2 {
    position: absolute;
    left: 90px;
    top: 26px;
}
.div5 h2 {
    position: absolute;
    left: 68px;
    top: 26px;
}
.box {
      width: 100%; /* Width is set to 100% for responsiveness */
      max-width: 250px; /* Maximum width for each box */
      height: 220px;
      background-color: whitesmoke; 
      margin:20px;
      border-radius:20px;
    }

    .services img{
        border-radius:20px;
        height:150px;
        width:250px;
    }
    .services a{
        text-decoration:none;
    }
    .services a:hover{
        text-decoration:none;
        color:red;
    }

        </style>
</head>
<body>

    <section>
	<div ><marquee scrollamount="15" behavior="alternate" direction="right" style="margin-top:8px;">
    <h2 > Register to enroll in Quiz Competition. </h2>
</marquee></div>

 <div class="maindiv"></div>
</section>
 
<div class="container contain">
        <div class="row">
            <div class="col-sm-4">
                <div class="card text-center"  style="border-radius:30px;">
                    <img src="card.jpg" alt="Card Image" class="img-responsive center-block" >
                    <div class="card-body">
                        <h4 class="card-title">PUNJAB QUIZ</h4>
                        <p class="card-text">Figure out if your History skills border on greatness.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card text-center" style="border-radius:30px;">
                    <img src="card1.jpg" alt="Card Image" class="img-responsive center-block">
                    <div class="card-body">
                        <h4 class="card-title">ELECTION QUIZ</h4>
                        <p class="card-text">Try to get high marks identifying these Questions.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card text-center" style="border-radius:30px;">
                    <img src="card2.jpg" alt="Card Image" class="img-responsive center-block">
                    <div class="card-body">
                        <h4 class="card-title">GENERAL QUIZ</h4>
                        <p class="card-text">Work smarter, not harder, to figure out these Questions.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> 

    <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="div1" data-aos="fade-right">
          <h1> Chief Electoral Officer Punjab</h1>
        <p> Shri Sibin C., IAS</p>
          <br />
          <hr />
          <br />
          <img class="imgg img-fluid" src="ceo.jpg" alt="C-DAC Mohali">
          <p>Information is power, and the key to democracy is ready and easy access to information on the part of the general public. Old style bureaucracies have been traditionally chary of parting with information, but the Election Commission of India has always been as transparent as possible, and has been urging its CEOs in the states to set up their own web-sites too.

At present we have placed the basic vital information, entire electoral rolls in PDF format, so that the citizens of Punjab can check whether their names figure on the rolls and where their polling station is located, General Lok Sabha Election/General Election to State Legislative Assembly Information. A search facility over electoral database to find the Voters and Polling Stations details are also available.

We seek the active co-operation of the citizens of Punjab for setting up a truly citizen-friendly, transparent and fair system. They are also requested to e-mail their suggestion for further improving the system and increasing public satisfaction.
          </p>
        </div>
      </div>
    </div>
</div>




<div class="container">
  <div id="carouselExample" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <div class="row services">

          <div class="col-md-4">
            <div class="box">
            <img src="register.jpg" alt="Card Image" class="img-fluid"> 
            <br/><br/>
            <a href="register.php" >  &nbsp; &nbsp;&nbsp;Click Here For Registration. </a>               
            </div>
          </div>

          <div class="col-md-4">
            <div class="box">
            <img src="certificate.jpg" alt="Card Image" class="img-fluid"> 
            <br/><br/>
            <a href="login.php" >  &nbsp; &nbsp;&nbsp;Click Here For Certificate.</a>   
            </div>
          </div>

          <div class="col-md-4">
            <div class="box">
            <img src="play.jpg" alt="Card Image" class="img-fluid"> 
            <br/><br/>
            <a href="login.php" >  &nbsp; &nbsp; &nbsp;Click Here For Play Quiz. </a>     
            </div>
          </div>

        </div>
    </div>
      <!-- Add more carousel items as needed -->
    </div>
</div>
</div>

  <!-- Bootstrap JS and AOS scripts -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8Wv5UutYXvb" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="path/to/aos.js"></script>
  <script>
    AOS.init();
  </script>


    </body>
    <!-- Bootstrap JS -->

</html>

