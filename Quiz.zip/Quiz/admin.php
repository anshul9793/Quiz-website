

<?php


include "connection.php";









$query = "SELECT * FROM questions";
$totalquestions = mysqli_num_rows(mysqli_query($conn,$query));

$query = "SELECT * FROM students";
$totalstudents = mysqli_num_rows(mysqli_query($conn,$query));

?>
<?php
include "adminnav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
 
   

   .main-container {
     width: 90%;
     max-width: 900px;
     text-align: center;
     margin: 40px auto;
   }

   .custom-div {
     height: 200px;
     margin: 10px;
     border-radius: 10px;
     display: flex;
     flex-direction: column;
     align-items: center;
     justify-content: center;
   }

   .color-1, .color-3 {
     background-color: #FF5733;
     width: 80%;
     height:80%;
   }

   .color-2 {
     background-color: #33FF57;
     width: 80%;
     height:80%;
   }

   .color-4 {
     background-color: white;
     width: 60%;
   }

   .color-5 {
     background-color: #33A1FF;
     width: 80%;
     height:80%;
   }
   .color-5 a {
     color: black;
   }

   .color-5 a:hover {
     color: blue;
     text-decoration: none;
   }
   .box img {
     border-radius: 10px;
     max-width: 100%;
     height: auto;
     margin-top: -10px;
   }

   .box a {
     font-weight: bold;
     color: black;
   }

   .box a:hover {
     color: blue;
     text-decoration: none;
   }
    
</style>
</head>

<body>

<div class="main-container">
    <div class="row">
      <div class="col-md-3">
      <a href="#" data-toggle="modal" data-target="#totalquestionsModal">

        <div class="custom-div color-1">
          <h5>Total Questions <br/><?php echo $totalquestions;?> </h5>
        </div>
        </a>

      </div>
      <div class="col-md-3">
      <a href="#" data-toggle="modal" data-target="#totalattemptedModal">

        <div class="custom-div color-2">
          <h5 style="text-align:center;">You have attempted <br/>7</h5>
        </div>
</a>
      </div>
      <div class="col-md-3">
      <a href="#" data-toggle="modal" data-target="#totalstudentsModal">

        <div class="custom-div color-3">
        <h5>Total Students <br/><?php echo $totalstudents;?> </h5>
        </div>
</a>
      </div>
      <div class="col-md-3">
      <a href="#" data-toggle="modal" data-target="#resultModal">

        <div class="custom-div color-5">
        <h5>See Your Result
        </h5>
        </div>
        </>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="custom-div color-4">
          <div class="box">
            <img src="certificate.jpg" alt="Card Image" class="img-fluid">
            <a href="certificate.php">Click Here For Certificate.</a>
          </div>
        </div>
      </div>
      
    </div>
  </div>

  <!-- Add this modal structure at the end of your HTML file -->
<div class="modal" tabindex="-1" role="dialog" id="totalquestionsModal">
  <div class="modal-dialog-centered" role="document">
    <div class="modal-content"  style="max-width: 900px; margin: auto;">

      <div class="modal-header">
      <h5 class="modal-title">Total Questions</h5>

        <button type="button" class="close"  style="position: absolute; left: 45%;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Add content you want to display in the modal here -->
        <p>Content related to total students goes here...</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <!-- Add this modal structure at the end of your HTML file -->
<div class="modal" tabindex="-1" role="dialog" id="totalattemptedModal">
  <div class="modal-dialog-centered" role="document">
    <div class="modal-content" style="max-width: 900px; margin: auto;">

      <div class="modal-header">
      <h5 class="modal-title">Total Attempted  Questions</h5>

        <button type="button" class="close"  style="position: absolute; left: 45%;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Add content you want to display in the modal here -->
        <p>Content related to total students goes here...</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <!-- Add this modal structure at the end of your HTML file -->
<div class="modal" tabindex="-1" role="dialog" id="totalstudentsModal">
  <div class="modal-dialog-centered" role="document">
    <div class="modal-content"  style=" margin: auto;">

      <div class="modal-header">
      <h5 class="modal-title">Total Students</h5>

        <button type="button" class="close"  style="position: absolute; left: 45%;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Add content you want to display in the modal here -->
        <p><div ">
        <h2 class="text-center ">Students Details</h2>

        <?php
        include "connection.php";

        $sql = "SELECT * FROM students";
        $result = $conn->query($sql);

        // Check for delete request
        
        if (isset($_GET['delete_id'])) {
            $delete_id = $conn->real_escape_string($_GET['delete_id']);
            $delete_sql = "DELETE FROM students WHERE id=?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $delete_id);
            $delete_stmt->execute();
            $delete_stmt->close();
            // echo "Data deleted";
            // header("Location: exp.php");
            
        }

        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered table-striped'>
                    <thead class='thead-dark'>
                        <tr>
                            <th>ID</th>
                          
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Gender</th>
                            <th>Role</th>
                            <th>Address</th>
                            <th>State</th>
                            <th>DoB</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>";

            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id"] . "</td>
                   
                        <td>" . htmlspecialchars($row["name"]) . "</td>
                        <td>" . htmlspecialchars($row["username"]) . "</td>
                        <td>" . htmlspecialchars($row["email"]) . "</td>
                        <td>" . $row["phone"] . "</td>
                        <td>" . htmlspecialchars($row["gender"]) . "</td>
                        <td>" . $row["role"] . "</td>
                        <td>" . htmlspecialchars($row["address"]) . "</td>
                        <td>" . htmlspecialchars($row["state"]) . "</td>
                        <td>" . $row["dob"] . "</td>
                        <td>
                            <a href='edit.php?id=" . $row["id"] . "' class='butn btn-primary btn-sm'>Edit</a>
                            <a href='" . $_SERVER['PHP_SELF'] . "?delete_id=" . $row["id"] . "' class='butn btn-danger btn-sm'>Delete</a>
                        </td>
                    </tr>";

            }

            echo "</tbody>
                </table>";
        } else {
            echo "0 results";
        }

        // Close connection
        $conn->close();
        ?>
                <button class="out"> <a  href="http://localhost/mohit/cdac/login.php">Logout</a> </button>

    </div></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <!-- Add this modal structure at the end of your HTML file -->
<div class="modal" tabindex="-1" role="dialog" id="resultModal">
  <div class="modal-dialog-centered" role="document">
    <div class="modal-content"  style=" margin: auto;">

      <div class="modal-header">
      <h5 class="modal-title">Your Result</h5>

        <button type="button" class="close"  style="position: absolute; left: 45%;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Add content you want to display in the modal here -->
        <p>Content related to total students goes here...</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

</body>
<!-- Add these lines to include Bootstrap CSS and JS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php
// include "foot.html";
?>
</html>