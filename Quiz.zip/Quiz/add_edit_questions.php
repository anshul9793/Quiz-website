<?php
include "admin_header.php";
include "connection.php";

// for show exam category
$id = isset($_GET["id"]) ? $_GET["id"] : null;
$exam_category = "";

if ($id) {
    $res = mysqli_query($conn, "SELECT * FROM exam_category WHERE id=$id");
    if ($res) {
        $row = mysqli_fetch_array($res);
        if ($row) {
            $exam_category = $row["category"];
        } else {
            echo "Exam not found.";
        }
    } else {
        echo "Error in SQL query: " . mysqli_error($conn);
    }
} else {
    echo "ID parameter not set.";
}

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit1"])) {
    $formSubmitted = true;

    $question = $conn->real_escape_string($_POST["question"]);
    $opt1 = $conn->real_escape_string($_POST["opt1"]);
    $opt2 = $conn->real_escape_string($_POST["opt2"]);
    $opt3 = $conn->real_escape_string($_POST["opt3"]);
    $opt4 = $conn->real_escape_string($_POST["opt4"]);
    $answer = $conn->real_escape_string($_POST["answer"]);

    // Validate if fields are not empty
    if (empty($question) || empty($opt1) || empty($opt2) || empty($opt3) || empty($opt4) || empty($answer)) {
        $errorMsg = "Please fill in all fields.";
    } else {
        // Retrieve existing questions count
        $countSql = "SELECT COUNT(*) FROM questions WHERE category = '$exam_category'";
        $result = mysqli_query($conn, $countSql);
        $row = mysqli_fetch_row($result);
        $loop = $row[0] + 1;

        // Insert new question
        $insertSql = $conn->prepare("INSERT INTO questions (question_no, question, op1, op2, op3, op4, answer, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insertSql->bind_param("isssssss", $loop, $question, $opt1, $opt2, $opt3, $opt4, $answer, $exam_category);

        if ($insertSql->execute()) {
            $successMsg = "Question added successfully!";
            $insertSql->close();
        } else {
            $errorMsg = "Error: " . $insertSql->error;
        }
    }
}
?>

<div class="breadcrumbs">
    <div class="col-sm-8">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Add Questions of <?php echo htmlspecialchars($exam_category); ?> </h1>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">

                        <div class="col-lg-8">
                            <form action="" name="form1" method="post">
                                <div class="card">
                                    <div class="card-header"><strong>Add New Questions</strong></div>
                                    <div class="card-body card-block">
                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Question </label><input type="text" name="question"
                                                placeholder="Add Question" class="form-control"></div>

                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Option 1</label><input type="text" name="opt1"
                                                placeholder="Add Option 1" class="form-control"></div>

                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Option 2</label><input type="text" name="opt2"
                                                placeholder="Add Option 2" class="form-control"></div>

                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Option 3</label><input type="text" name="opt3"
                                                placeholder="Add Option 3" class="form-control"></div>

                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Option 4</label><input type="text" name="opt4"
                                                placeholder="Add Option 4" class="form-control"></div>

                                        <div class="form-group"><label for="company" class=" form-control-label"> Add Answer</label><input type="text" name="answer"
                                                placeholder="Add Answer" class="form-control"></div>

                                        <div class="form-group">
                                            <input type="submit" name="submit1" value="Add question" class="btn btn-success">
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php
                            if (!empty($successMsg)) {
                                echo '<div class="alert alert-success" role="alert">' . $successMsg . '</div>';
                            }
                            if (!empty($errorMsg)) {
                                echo '<div class="alert alert-danger" role="alert">' . $errorMsg . '</div>';
                            }
                            ?>
                        </div>

                        <!-- Your content here -->
                    </div>
                </div> <!-- .card -->
            </div>
        </div>
    </div>
</div>

<?php
include "admin_footer.php";
?>
