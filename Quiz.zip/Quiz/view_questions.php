<?php
include "admin_header.php";
include "connection.php";

// Check if the delete button is clicked
if (isset($_GET["delete_id"])) {
    $delete_id = $_GET["delete_id"];

    $getCategorySql = "SELECT category FROM questions WHERE id = $delete_id";
    $getCategoryResult = mysqli_query($conn, $getCategorySql);

    if ($getCategoryResult && $categoryRow = mysqli_fetch_assoc($getCategoryResult)) {
        $categoryName = $categoryRow["category"];

        $deleteSql = "DELETE FROM questions WHERE id = $delete_id";
        $deleteResult = mysqli_query($conn, $deleteSql);

        if ($deleteResult) {
            $successMsg = "Question deleted successfully !";
        } else {
            $errorMsg = "Error deleting question: " . mysqli_error($conn);
        }
    }
}

$user_id = 0;

// Fetch all categories for the logged-in user
$categoriesSql = "SELECT * FROM exam_category";
$categoriesResult = mysqli_query($conn, $categoriesSql);
?>

<div class="breadcrumbs">
    <div class="col-sm-8">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>View Questions</h1>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        while ($category = mysqli_fetch_array($categoriesResult)) {
                            $categoryId = $category["id"];
                            $categoryName = $category["category"];

                            $questionsSql = "SELECT * FROM questions WHERE category = '$categoryName'";
                            $questionsResult = mysqli_query($conn, $questionsSql);
                        ?>

                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Questions for <?php echo htmlspecialchars($categoryName); ?></strong>
                                    </div>
                                    <div class="card-body card-block">
                                        <?php
                                        if (isset($successMsg) && $categoryName == $categoryRow["category"]) {
                                            echo '<div class="alert alert-success" role="alert">' . $successMsg . '</div>';
                                        }
                                        if (isset($errorMsg) && $categoryName == $categoryRow["category"]) {
                                            echo '<div class="alert alert-danger" role="alert">' . $errorMsg . '</div>';
                                        }
                                        ?>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Question</th>
                                                    <th>Option 1</th>
                                                    <th>Option 2</th>
                                                    <th>Option 3</th>
                                                    <th>Option 4</th>
                                                    <th>Answer</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php
                                                while ($question = mysqli_fetch_array($questionsResult)) {
                                                ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($question['question']); ?></td>
                                                        <td><?php echo htmlspecialchars($question['op1']); ?></td>
                                                        <td><?php echo htmlspecialchars($question['op2']); ?></td>
                                                        <td><?php echo htmlspecialchars($question['op3']); ?></td>
                                                        <td><?php echo htmlspecialchars($question['op4']); ?></td>
                                                        <td><?php echo htmlspecialchars($question['answer']); ?></td>
                                                        <td>
                                                            <a href="edit_questions.php?id=<?php echo $question['id']; ?>">Edit</a>
                                                            
                                                            <a href="?delete_id=<?php echo $question['id']; ?>">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        <?php
                        }
                        ?>

                    </div>
                </div> <!-- .card -->
            </div>
        </div>
    </div>
</div>

<?php
include "admin_footer.php";
?>
