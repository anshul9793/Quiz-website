<?php
include "admin_header.php";
include "connection.php";

// Fetch data from the exam_category table
$sql = "SELECT * FROM exam_category";
$result = $conn->query($sql);

?>

<div class="container mt-5 mb-5">
    <h2 class="text-center">List of Exams</h2>

    <?php
    if ($result->num_rows > 0) {
        echo "<table class='table'>
            <thead>
                <tr>
                    <th>Sr. no.</th>
                    <th>Exam Category</th>
                    <th>Exam Time (Minutes)</th>
                    <th>Add & edit questions</th>
                </tr>
            </thead>
            <tbody>";

        $serialNumber = 1;
        // Output data of each row
      // Output data of each row
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $serialNumber . "</td>
            <td>" . htmlspecialchars($row["category"]) . "</td>
            <td>" . htmlspecialchars($row["exam_time_in_minutes"]) . "</td>
            <td>
                <a href='add_edit_questions.php?id=" . $row["id"] . "'>Select</a>
            </td>
        </tr>";
    $serialNumber++;
}


        echo "</tbody></table>";
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
    ?>

    
</div>

<?php
include "admin_footer.php";
?>
