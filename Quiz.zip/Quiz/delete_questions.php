<?php
include "admin_header.php";
include "connection.php";

$id = isset($_GET["id"]) ? $_GET["id"] : null;

if (!$id) {
    echo "Question ID not provided.";
    exit;
}

$deleteSql = "DELETE FROM questions WHERE id = $id";
$deleteResult = mysqli_query($conn, $deleteSql);

if ($deleteResult) {
    $successMsg = "Question deleted successfully!";
} else {
    $errorMsg = "Error deleting question: " . mysqli_error($conn);
}
?>

<div class="breadcrumbs">
    <div class="col-sm-8">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Delete Question</h1>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <strong>Delete Question</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php
                        if (isset($successMsg)) {
                            echo '<div class="alert alert-success" role="alert">' . $successMsg . '</div>';
                        }
                        if (isset($errorMsg)) {
                            echo '<div class="alert alert-danger" role="alert">' . $errorMsg . '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "admin_footer.php";
?>
