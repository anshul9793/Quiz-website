<?php 

include "connection.php";



$query = "SELECT * FROM questions";
$totalquestions = mysqli_num_rows(mysqli_query($conn,$query));

?>
<?php
include "nav2.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
   

    .main-container {
      width: 90%;
      max-width: 900px;
      text-align: center;
      margin: 40px auto;
    }

    .custom-div {
      height: 200px;
      margin: 10px;
      border-radius: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .color-1, .color-3 {
      background-color: #FF5733;
      width: 80%;
      height:80%;
    }

    .color-2 {
      background-color: #33FF57;
      width: 80%;
      height:80%;
    }

    .color-4 {
      background-color: white;
      width: 60%;
    }

    .color-5 {
      background-color: #33A1FF;
      width: 80%;
      height:80%;
    }
    .color-5 a {
      color: black;
    }

    .color-5 a:hover {
      color: blue;
      text-decoration: none;
    }
    .box img {
      border-radius: 10px;
      max-width: 100%;
      height: auto;
      margin-top: -10px;
    }

    .box a {
      font-weight: bold;
      color: black;
    }

    .box a:hover {
      color: blue;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <div class="main-container">
    <div class="row">
      <div class="col-md-3">
        <div class="custom-div color-1">
          <h5>Total Questions <br/><?php echo $totalquestions;?> </h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="custom-div color-2">
          <h5 style="text-align:center;">You have attempted <br/>7</h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="custom-div color-3">
          <h5>You have scored <br/> <?php echo $_SESSION['score'];?></h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="custom-div color-5">
        <h5><a href=" ">See Your Result </a>
        </h5>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="custom-div color-4">
          <div class="box">
            <img src="certificate.jpg" alt="Card Image" class="img-fluid">
            <a href="certificate.php">Click Here For Certificate.</a>
          </div>
        </div>
      </div>
      
    </div>
  </div>

  <!-- Bootstrap JS and jQuery (for dropdown functionality) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
<?php
include "foot.html";
?>
</html>

