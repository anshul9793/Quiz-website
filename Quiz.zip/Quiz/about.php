<?php
include "nav.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .div1{
    background-color: whitesmoke;
    border-radius: 10px;
  padding: 20px;
}
.div1 h1{
    color: #324a8e;
}
    </style>
<body>
    <div class="container266">
  
    <div class="div1" data-aos="fade-right">
        <h1> About Us</h1>
       <br/> <hr/><br/>
        <img class="imgg" src="new.png" >
    <p>The site has primarily been made to improve communication between the electors of Punjab and the department of elections in Punjab. It provides adequate and relevant information about the office of the Chief Electoral Officer and the various activities conducted by the department. Various important forms are also available on the site for download purposes.
    We seek the active co-operation of the citizens of Punjab for setting up a truly citizen-friendly, transparent and fair system. They are also requested to e-mail their suggestion for further improving the system and increasing public satisfaction.  </p> 
            </div>
</div>

</body>
<?php
include "foot.html";
?>
</html>